package br.com.erudio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestWithSpringBootAndJavaErudioApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestWithSpringBootAndJavaErudioApplication.class, args);
	}

}
